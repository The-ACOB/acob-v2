import type { Metadata } from "next";
import { requireAuth } from "@/lib/authz/guards";
import { db } from "@/lib/db/client";
import { DashboardPageHeader } from "@/components/dashboard/PageHeader";
import { ParticipantProfileForm } from "@/components/dashboard/ParticipantProfileForm";

export const metadata: Metadata = { title: "My Profile" };

function academicLevelForGrade(value: string | null | undefined) {
  const grade = Number.parseInt(value?.trim() ?? "", 10);
  if (grade >= 6 && grade <= 8) return "Junior Secondary";
  if (grade >= 9 && grade <= 10) return "Secondary";
  if (grade >= 11 && grade <= 12) return "Higher Secondary";
  return "";
}

export default async function ProfilePage() {
  const session = await requireAuth();
  let [profile, participant] = await Promise.all([
    db.profile.findUnique({ where: { userId: session.id } }),
    db.participant.findUnique({ where: { userId: session.id } }),
  ]);

  if (!profile) {
    profile = await db.profile.create({
      data: { userId: session.id, fullName: session.fullName ?? session.email },
    });
  }
  if (!participant && session.roleKeys.includes("PARTICIPANT")) {
    participant = await db.participant.create({ data: { userId: session.id } });
  }

  return (
    <div>
      <DashboardPageHeader
        title="My profile"
        description="Keep your account and profile information up to date."
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "My profile" },
        ]}
      />
      <p className="mt-6 text-sm text-secondary">
        Email: {session.email} (email changes require verification and are not
        enabled in this account flow)
      </p>
      <ParticipantProfileForm
        userId={session.id}
        initialAvatarUrl={profile.avatarUrl}
        showParticipantFields={Boolean(participant)}
        defaultValues={{
          email: session.email,
          fullName: profile.fullName,
          bio: profile.bio ?? "",
          phone: profile.phone ?? "",
          gender: participant?.gender ?? "",
          institution: participant?.institution ?? "",
          gradeLevel: participant?.gradeLevel ?? "",
          academicLevel:
            academicLevelForGrade(participant?.gradeLevel) ||
            participant?.academicLevel ||
            "",
          district: participant?.district ?? "",
          address: participant?.address ?? "",
          city: participant?.city ?? "",
        }}
      />
    </div>
  );
}
