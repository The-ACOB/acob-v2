import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppSupport } from "@/components/layout/WhatsAppSupport";
import { PopupBanner } from "@/components/effects/PopupBanner";
import { getCurrentSession } from "@/lib/auth/session";
import { getActivePopup } from "@/lib/popups/query";

export default async function PublicLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [session, popup] = await Promise.all([
    getCurrentSession(),
    getActivePopup(),
  ]);

  return (
    <div className="public-shell flex min-h-dvh flex-col">
      <PopupBanner popup={popup} />
      <Header
        user={
          session
            ? {
                email: session.email,
                fullName: session.fullName,
                avatarUrl: session.avatarUrl,
              }
            : null
        }
      />
      <main className="flex-1">{children}</main>
      <Footer />
      <WhatsAppSupport />
    </div>
  );
}
