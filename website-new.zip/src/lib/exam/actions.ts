"use server";

import { requireAuth, AuthError } from "@/lib/authz/guards";
import { db } from "@/lib/db/client";
import { computeDeadline, autoSubmitIfExpired } from "./timer";
import { scoreAttempt } from "./scoring";
import type { ActionResult } from "@/lib/auth/actions";
import type { Olympiad } from "@prisma/client";
import { isEligibleForOlympiad } from "./eligibility";
import { isExamLive, isRegistrationOpen } from "@/lib/olympiads/lifecycle";

const EXAM_ROLES = ["PARTICIPANT", "AMBASSADOR"];

/** Lazily flips a scheduled Olympiad to "published" once its publishAt has passed. */
async function resolveEffectiveOlympiad(id: string): Promise<Olympiad | null> {
  const olympiad = await db.olympiad.findUnique({ where: { id } });

  if (!olympiad) return null;

  if (
    olympiad.status === "draft" &&
    olympiad.publishAt &&
    olympiad.publishAt.getTime() <= Date.now()
  ) {
    return db.olympiad.update({
      where: { id },
      data: { status: "published" },
    });
  }

  return olympiad;
}

function isBeforeExam(olympiad: Olympiad): boolean {
  return Boolean(olympiad.startAt && Date.now() < olympiad.startAt.getTime());
}

/**
 * A registration is only considered valid for exam access once it is confirmed.
 *
 * Free Olympiads become confirmed immediately.
 * Paid Olympiads remain pending until an authorized admin approves payment.
 */
function isConfirmedRegistration(
  registration: { status: string } | null,
): boolean {
  return registration?.status === "confirmed";
}

export async function registerForOlympiadAction(
  olympiadId: string,
): Promise<ActionResult> {
  let session;

  try {
    session = await requireAuth();
  } catch (err) {
    if (err instanceof AuthError) return { ok: false, error: err.message };
    throw err;
  }

  if (!session.roleKeys.some((r) => EXAM_ROLES.includes(r))) {
    return { ok: false, error: "Only participants can register." };
  }

  const olympiad = await resolveEffectiveOlympiad(olympiadId);

  if (!olympiad || olympiad.status !== "published") {
    return { ok: false, error: "Registration is not open." };
  }

  if (!isRegistrationOpen(olympiad)) {
    return { ok: false, error: "Registration is closed." };
  }

  if (!(await isEligibleForOlympiad(olympiad, session.id))) {
    return { ok: false, error: "You are not eligible to register." };
  }

  /*
   * Paid Olympiads cannot be registered through the old one-click flow.
   * The payment form will create the pending registration together with
   * the submitted payment details.
   */
  if (olympiad.registrationType === "paid") {
    return {
      ok: false,
      error:
        "This is a paid Olympiad. Submit your bKash payment details to complete registration.",
    };
  }

  await db.olympiadRegistration.upsert({
    where: {
      olympiadId_userId: {
        olympiadId,
        userId: session.id,
      },
    },
    create: {
      olympiadId,
      userId: session.id,
      status: "confirmed",
      confirmedAt: new Date(),
    },
    update: {
      status: "confirmed",
      confirmedAt: new Date(),
    },
  });

  return { ok: true };
}

export async function recordIntegrityViolationAction(
  attemptId: string,
  reason: string,
): Promise<ActionResult<{ count: number; autoSubmitted: boolean }>> {
  void reason;

  let session;

  try {
    session = await requireAuth();
  } catch (err) {
    if (err instanceof AuthError) return { ok: false, error: err.message };
    throw err;
  }

  const attempt = await db.attempt.findUnique({
    where: { id: attemptId },
  });

  if (
    !attempt ||
    attempt.userId !== session.id ||
    attempt.status !== "in_progress"
  ) {
    return { ok: false, error: "Attempt not found." };
  }

  const updated = await db.attempt.updateMany({
    where: {
      id: attemptId,
      status: "in_progress",
      integrityViolationCount: { lt: 3 },
    },
    data: {
      integrityViolationCount: { increment: 1 },
    },
  });

  if (updated.count !== 1) {
    return { ok: false, error: "Attempt is no longer active." };
  }

  const current = await db.attempt.findUnique({
    where: { id: attemptId },
  });

  const count = current?.integrityViolationCount ?? 0;

  if (count >= 3) {
    // Three integrity violations disqualify the participant. A disqualified
    // attempt is intentionally never scored or ranked, so it can never earn
    // Prime, Elite, Merit, Honourable Mention, or Participation recognition.
    await db.attempt.update({
      where: { id: attemptId },
      data: {
        status: "disqualified",
        submittedAt: new Date(),
        score: null,
        totalMarks: null,
        correctCount: null,
        incorrectCount: null,
        unansweredCount: null,
        timeSpentSeconds: Math.round(
          (Date.now() - attempt.startedAt.getTime()) / 1000,
        ),
        autoSubmissionReason: "integrity_violation",
        autoSubmittedAt: new Date(),
        rank: null,
        scoreLocked: true,
      },
    });

    return {
      ok: true,
      data: {
        count,
        autoSubmitted: true,
      },
    };
  }

  return {
    ok: true,
    data: {
      count,
      autoSubmitted: false,
    },
  };
}

export async function startAttemptAction(
  olympiadId: string,
): Promise<ActionResult<{ attemptId: string }>> {
  let session;

  try {
    session = await requireAuth();
  } catch (err) {
    if (err instanceof AuthError) return { ok: false, error: err.message };
    throw err;
  }

  if (!session.roleKeys.some((r) => EXAM_ROLES.includes(r))) {
    return {
      ok: false,
      error: "Only participants and ambassadors can take Olympiads.",
    };
  }

  const olympiad = await resolveEffectiveOlympiad(olympiadId);

  if (!olympiad || olympiad.status !== "published") {
    return {
      ok: false,
      error: "This Olympiad is not currently available.",
    };
  }

  if (isBeforeExam(olympiad)) {
    return {
      ok: false,
      error: "This Olympiad has not started yet.",
    };
  }

  if (!(await isEligibleForOlympiad(olympiad, session.id))) {
    return {
      ok: false,
      error: "You are not eligible to attempt this Olympiad.",
    };
  }

  const registration = await db.olympiadRegistration.findUnique({
    where: {
      olympiadId_userId: {
        olympiadId,
        userId: session.id,
      },
    },
  });

  if (!registration) {
    return {
      ok: false,
      error: "Register for this Olympiad before starting the exam.",
    };
  }

  if (!isConfirmedRegistration(registration)) {
    if (registration.status === "pending_payment") {
      return {
        ok: false,
        error: "Payment is required before you can start this Olympiad.",
      };
    }

    if (registration.status === "pending_approval") {
      return {
        ok: false,
        error:
          "Your payment is waiting for admin approval before you can start the Olympiad.",
      };
    }

    if (registration.status === "rejected") {
      return {
        ok: false,
        error:
          "Your registration payment was rejected. Please submit valid payment details.",
      };
    }

    return {
      ok: false,
      error: "Your registration is not confirmed.",
    };
  }

  const questionCount = await db.question.count({
    where: { olympiadId },
  });

  if (questionCount === 0) {
    return {
      ok: false,
      error: "This exam is not ready yet. Questions have not been added.",
    };
  }

  const existing = await db.attempt.findUnique({
    where: {
      olympiadId_userId: {
        olympiadId,
        userId: session.id,
      },
    },
  });

  if (existing) {
    const refreshed = await autoSubmitIfExpired(existing, olympiad);

    if (refreshed.status !== "in_progress") {
      return {
        ok: false,
        error: "You have already attempted this Olympiad.",
      };
    }

    return {
      ok: true,
      data: {
        attemptId: refreshed.id,
      },
    };
  }

  if (!isExamLive(olympiad)) {
    return {
      ok: false,
      error: "This Olympiad is not open for new attempts right now.",
    };
  }

  const startedAt = new Date();
  const deadlineAt = computeDeadline(olympiad, startedAt);

  const attempt = await db.attempt.create({
    data: {
      olympiadId,
      userId: session.id,
      deadlineAt,
    },
  });

  return {
    ok: true,
    data: {
      attemptId: attempt.id,
    },
  };
}

/**
 * Debounced from the client, called on question navigation or every
 * ~15s while an answer is selected, never per keystroke/millisecond.
 */
export async function saveAnswerAction(
  attemptId: string,
  questionId: string,
  selectedOptionId: string | null,
  timeSpentDeltaSeconds: number,
): Promise<ActionResult> {
  let session;

  try {
    session = await requireAuth();
  } catch (err) {
    if (err instanceof AuthError) return { ok: false, error: err.message };
    throw err;
  }

  const attempt = await db.attempt.findUnique({
    where: { id: attemptId },
  });

  if (!attempt || attempt.userId !== session.id) {
    return { ok: false, error: "Attempt not found." };
  }

  const olympiad = await db.olympiad.findUnique({
    where: { id: attempt.olympiadId },
  });

  if (!olympiad) {
    return { ok: false, error: "Olympiad not found." };
  }

  if (olympiad.status !== "published" || isBeforeExam(olympiad)) {
    return {
      ok: false,
      error: "The exam questions are not available yet.",
    };
  }

  if (!(await isEligibleForOlympiad(olympiad, session.id))) {
    return {
      ok: false,
      error: "You are not eligible to access this exam.",
    };
  }

  const registration = await db.olympiadRegistration.findUnique({
    where: {
      olympiadId_userId: {
        olympiadId: olympiad.id,
        userId: session.id,
      },
    },
  });

  if (!registration) {
    return {
      ok: false,
      error: "Exam registration not found.",
    };
  }

  if (!isConfirmedRegistration(registration)) {
    return {
      ok: false,
      error: "Your registration is not confirmed.",
    };
  }

  const current = await autoSubmitIfExpired(attempt, olympiad);

  if (current.status !== "in_progress") {
    return {
      ok: false,
      error: "Time has expired for this attempt.",
    };
  }

  const questionCount = await db.question.count({
    where: { olympiadId: attempt.olympiadId },
  });

  if (questionCount === 0) {
    return {
      ok: false,
      error: "This exam has no questions yet.",
    };
  }

  const question: {
    id: string;
    olympiadId: string;
    options: { id: string }[];
  } | null = await db.question.findUnique({
    where: { id: questionId },
    include: { options: true },
  });

  if (!question || question.olympiadId !== attempt.olympiadId) {
    return {
      ok: false,
      error: "Question does not belong to this attempt.",
    };
  }

  if (
    selectedOptionId &&
    !question.options.some((o) => o.id === selectedOptionId)
  ) {
    return {
      ok: false,
      error: "Invalid option for this question.",
    };
  }

  const existingAnswer = await db.attemptAnswer.findUnique({
    where: {
      attemptId_questionId: {
        attemptId,
        questionId,
      },
    },
  });

  const changed = Boolean(
    existingAnswer && existingAnswer.selectedOptionId !== selectedOptionId,
  );

  const now = new Date();

  await db.attemptAnswer.upsert({
    where: {
      attemptId_questionId: {
        attemptId,
        questionId,
      },
    },
    update: {
      selectedOptionId,
      timeSpentSeconds:
        (existingAnswer?.timeSpentSeconds ?? 0) +
        Math.max(0, Math.round(timeSpentDeltaSeconds)),
      changeCount: (existingAnswer?.changeCount ?? 0) + (changed ? 1 : 0),
      lastInteractionAt: now,
    },
    create: {
      attemptId,
      questionId,
      selectedOptionId,
      timeSpentSeconds: Math.max(0, Math.round(timeSpentDeltaSeconds)),
      changeCount: 0,
      firstAnsweredAt: now,
      lastInteractionAt: now,
    },
  });

  return { ok: true };
}

/**
 * Scores are computed here, server-side, from the question's own
 * option data. A participant only learns their score from the results
 * page, and only once the Olympiad's results have been officially
 * published.
 */
export async function submitAttemptAction(
  attemptId: string,
  autoSubmissionReason?: string,
): Promise<ActionResult> {
  let session;

  try {
    session = await requireAuth();
  } catch (err) {
    if (err instanceof AuthError) return { ok: false, error: err.message };
    throw err;
  }

  const attempt = await db.attempt.findUnique({
    where: { id: attemptId },
  });

  if (!attempt || attempt.userId !== session.id) {
    return { ok: false, error: "Attempt not found." };
  }

  const olympiad = await db.olympiad.findUnique({
    where: { id: attempt.olympiadId },
  });

  if (!olympiad) {
    return { ok: false, error: "Olympiad not found." };
  }

  if (olympiad.status !== "published" || isBeforeExam(olympiad)) {
    return {
      ok: false,
      error: "The exam questions are not available yet.",
    };
  }

  if (!(await isEligibleForOlympiad(olympiad, session.id))) {
    return {
      ok: false,
      error: "You are not eligible to submit this exam.",
    };
  }

  const registration = await db.olympiadRegistration.findUnique({
    where: {
      olympiadId_userId: {
        olympiadId: olympiad.id,
        userId: session.id,
      },
    },
  });

  if (!registration || !isConfirmedRegistration(registration)) {
    return {
      ok: false,
      error: "Your registration is not confirmed.",
    };
  }

  const current = await autoSubmitIfExpired(attempt, olympiad);

  if (current.status !== "in_progress") {
    return {
      ok: false,
      error: "This attempt has already been submitted.",
    };
  }

  const questionCount = await db.question.count({
    where: { olympiadId: attempt.olympiadId },
  });

  if (questionCount === 0) {
    return {
      ok: false,
      error: "This exam has no questions yet.",
    };
  }

  const questions: {
    id: string;
    marks: number;
    options: { id: string; isCorrect: boolean }[];
  }[] = await db.question.findMany({
    where: { olympiadId: attempt.olympiadId },
    include: { options: true },
  });

  const answers: {
    questionId: string;
    selectedOptionId: string | null;
  }[] = await db.attemptAnswer.findMany({
    where: { attemptId },
  });

  const result = scoreAttempt(
    questions,
    answers,
    olympiad.negativeMarkingEnabled,
    olympiad.negativeMarkingValue,
  );

  const submittedAt = new Date();

  await db.attempt.update({
    where: { id: attemptId },
    data: {
      status: "submitted",
      submittedAt,
      score: result.score,
      totalMarks: result.totalMarks,
      correctCount: result.correctCount,
      incorrectCount: result.incorrectCount,
      unansweredCount: result.unansweredCount,
      timeSpentSeconds: Math.round(
        (submittedAt.getTime() - attempt.startedAt.getTime()) / 1000,
      ),
      ...(autoSubmissionReason
        ? {
            status: "expired_auto_submitted" as const,
            autoSubmissionReason,
            autoSubmittedAt: submittedAt,
          }
        : {}),
    },
  });

  for (const [questionId, outcome] of result.perQuestion) {
    if (!answers.some((a) => a.questionId === questionId)) continue;

    await db.attemptAnswer.upsert({
      where: {
        attemptId_questionId: {
          attemptId,
          questionId,
        },
      },
      update: {
        isCorrect: outcome.isCorrect,
        marksAwarded: outcome.marksAwarded,
      },
      create: {
        attemptId,
        questionId,
        isCorrect: outcome.isCorrect,
        marksAwarded: outcome.marksAwarded,
      },
    });
  }

  return { ok: true };
}

export type SanitizedOption = {
  id: string;
  text: string;
};

export type SanitizedQuestion = {
  id: string;
  text: string;
  imageUrl: string | null;
  marks: number;
  order: number;
  options: SanitizedOption[];
};

/**
 * Fetches everything the exam-taking UI needs, with `isCorrect` and
 * `explanation` stripped from every question before it ever leaves
 * the server.
 */
export async function getExamData(attemptId: string): Promise<
  | {
      ok: true;
      attempt: {
        id: string;
        deadlineAt: string;
        status: string;
      };
      questions: SanitizedQuestion[];
      existingAnswers: Record<string, string | null>;
    }
  | { ok: false; error: string }
> {
  const session = await requireAuth().catch(() => null);

  if (!session) {
    return {
      ok: false,
      error: "Authentication required.",
    };
  }

  const attempt = await db.attempt.findUnique({
    where: { id: attemptId },
  });

  if (!attempt || attempt.userId !== session.id) {
    return {
      ok: false,
      error: "Attempt not found.",
    };
  }

  const olympiad = await db.olympiad.findUnique({
    where: { id: attempt.olympiadId },
  });

  if (!olympiad) {
    return {
      ok: false,
      error: "Olympiad not found.",
    };
  }

  if (olympiad.status !== "published" || isBeforeExam(olympiad)) {
    return {
      ok: false,
      error: "The exam questions are not available yet.",
    };
  }

  const registration = await db.olympiadRegistration.findUnique({
    where: {
      olympiadId_userId: {
        olympiadId: olympiad.id,
        userId: session.id,
      },
    },
  });

  if (!registration || !isConfirmedRegistration(registration)) {
    return {
      ok: false,
      error: "Your registration is not confirmed.",
    };
  }

  const current = await autoSubmitIfExpired(attempt, olympiad);

  if (current.status !== "in_progress") {
    return {
      ok: false,
      error: "This attempt is no longer in progress.",
    };
  }

  const questionCount = await db.question.count({
    where: { olympiadId: attempt.olympiadId },
  });

  if (questionCount === 0) {
    return {
      ok: false,
      error: "This exam has no questions yet.",
    };
  }

  const rawQuestions: {
    id: string;
    text: string;
    imageUrl: string | null;
    marks: number;
    order: number;
    options: {
      id: string;
      text: string;
      isCorrect: boolean;
    }[];
  }[] = await db.question.findMany({
    where: { olympiadId: attempt.olympiadId },
    include: { options: true },
  });

  const questions: SanitizedQuestion[] = rawQuestions
    .sort((a, b) => a.order - b.order)
    .map((q) => ({
      id: q.id,
      text: q.text,
      imageUrl: q.imageUrl,
      marks: q.marks,
      order: q.order,
      options: q.options.map((o) => ({
        id: o.id,
        text: o.text,
      })),
    }));

  const answers: {
    questionId: string;
    selectedOptionId: string | null;
  }[] = await db.attemptAnswer.findMany({
    where: { attemptId: current.id },
  });

  const existingAnswers: Record<string, string | null> = {};

  for (const answer of answers) {
    existingAnswers[answer.questionId] = answer.selectedOptionId;
  }

  return {
    ok: true,
    attempt: {
      id: current.id,
      deadlineAt: current.deadlineAt.toISOString(),
      status: current.status,
    },
    questions,
    existingAnswers,
  };
}
